package bd.example.airtelchecker

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var result: TextView
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(24))
            setBackgroundColor(0xFFF3F6FA.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "🛡️ Airtel VPN ও Network Checker"
            textSize = 23f; setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF10233F.toInt())
        }
        root.addView(title)
        val intro = TextView(this).apply {
            text = "নিজের/অনুমোদিত VPN সার্ভার ব্যবহার করুন। VPN চালাতে মোবাইল ডেটা বা Wi-Fi সংযোগ প্রয়োজন।"
            textSize = 15f; setPadding(0, dp(12), 0, dp(16))
        }
        root.addView(intro)
        val wireguard = Button(this).apply {
            text = "WireGuard খুলুন / কনফিগ আমদানি করুন"
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage("com.wireguard.android")
                if (launch != null) startActivity(launch)
                else {
                    result.text = "WireGuard অ্যাপ ইনস্টল নেই। Play Store থেকে অফিসিয়াল WireGuard ইনস্টল করুন, তারপর আপনার .conf ফাইল Import করুন।"
                    try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://play.google.com/store/apps/details?id=com.wireguard.android"))) } catch (_: Exception) {}
                }
            }
        }
        root.addView(wireguard, match())
        val test = Button(this).apply {
            text = "নেটওয়ার্ক পরীক্ষা করুন"
            setOnClickListener { runTest() }
        }
        root.addView(test, match())
        result = TextView(this).apply {
            text = "পরীক্ষা শুরু করতে উপরের বাটন চাপুন।"
            textSize = 16f; setTextColor(0xFF152238.toInt())
            setPadding(dp(14), dp(16), dp(14), dp(16))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(16)
        root.addView(result, lp)
        val note = TextView(this).apply {
            text = "\nনিরাপত্তা: আপনার WireGuard PrivateKey বা কনফিগারেশন অন্য কাউকে দেবেন না। এই পরীক্ষাটি ইন্টারনেট চালু করে না এবং অপারেটরের চার্জ/ডেটা সীমা এড়িয়ে যায় না।"
            textSize = 13f
        }
        root.addView(note)
    }

    private fun match() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        topMargin = dp(8)
    }

    private fun runTest() {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val caps = network?.let { cm.getNetworkCapabilities(it) }
        val connected = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val validated = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        val vpn = caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        result.text = "নেটওয়ার্ক পরীক্ষা চলছে…\nসিস্টেম নেটওয়ার্ক: ${if (connected) "সংযুক্ত" else "সংযুক্ত নয়"}\nAndroid ইন্টারনেট যাচাই: ${if (validated) "সফল" else "যাচাই হয়নি"}\nVPN transport: ${if (vpn) "সক্রিয় বলে শনাক্ত" else "সক্রিয় হিসেবে শনাক্ত হয়নি"}\nHTTPS পরীক্ষা: চলছে…"
        thread {
            var outcome = "ব্যর্থ বা টাইমআউট"
            var ms = -1L
            try {
                val start = System.currentTimeMillis()
                val c = (URL("https://www.google.com/generate_204").openConnection() as HttpURLConnection)
                c.connectTimeout = 5000; c.readTimeout = 5000; c.requestMethod = "GET"
                c.connect()
                ms = System.currentTimeMillis() - start
                outcome = if (c.responseCode in 200..399) "সফল" else "HTTP ${c.responseCode}"
                c.disconnect()
            } catch (_: Exception) {}
            val finalOutcome = outcome
            val finalMs = ms
            runOnUiThread {
                result.text = "নেটওয়ার্ক পরীক্ষা সম্পন্ন\nসিস্টেম নেটওয়ার্ক: ${if (connected) "সংযুক্ত" else "সংযুক্ত নয়"}\nAndroid ইন্টারনেট যাচাই: ${if (validated) "সফল" else "যাচাই হয়নি"}\nVPN transport: ${if (vpn) "সক্রিয় বলে শনাক্ত" else "সক্রিয় হিসেবে শনাক্ত হয়নি"}\nHTTPS endpoint: $finalOutcome${if (finalMs >= 0) " (${finalMs} ms)" else ""}\n\nনোট: VPN শনাক্তকরণ Android-এর বর্তমান নেটওয়ার্কের ভিত্তিতে; এটি সার্ভারের নিরাপত্তা বা আনলিমিটেড ইন্টারনেটের নিশ্চয়তা নয়।"
            }
        }
    }
}
